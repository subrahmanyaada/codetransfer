module.exports = {
  rabbitMQ: {
    url: "amqp://127.0.0.1"
  },
  consumeQ: {
    exchangeName: "logExchange",
    qName: "InfoQueue",
    routingKey: "Info"
  },
  dispatchQ: {
    exchangeName: "dispatcherEx",
    qName: "dispatcherQ",
    routingKey: "dispatch"
  }
};
