const redis = require('redis');

// Create a Redis client
const client = redis.createClient({
  host: '127.0.0.1', 
  port: 6379,
});



async function storeToRedis(key,value){
client.set(key, value, (err, reply) => {
  if (err) {
  
    console.error(' Error While Storing Schema To Redis', err);

  } else {
    console.log('Schema Stored Successfully:', reply);
  }
});
}


async function storeTransformedMessage(transformedMessage){

  const msgId= 't'+ transformedMessage["msgId"];

  console.log("MsgID", msgId)

  const payloadString=JSON.stringify(transformedMessage.transformedData);

  storeToRedis(msgId,payloadString)

}


module.exports = {storeTransformedMessage}
