const BMP_API_Map = new Map();
// Add key-value pairs to the map
BMP_API_Map.set('Freeform message with only text', 'message');
BMP_API_Map.set('Freeform message with image', 'message/media');
BMP_API_Map.set('Templatized text message', 'message');
BMP_API_Map.set('Templatized message with text header', 'message');



//Super function to transform the CleverTap payload to BMP payload
function transform(payload) {
  //checking whether the payload is of template message or freeform message
  if (payload.isTemplate) {
    let start = Date.now()

    //calling the function to transform the template message paylaod
    const transformedData = transformTemplateMessagePayload(payload)

   

    return transformedData;

  } else {
    let start = Date.now()

    //calling the function to transform the freeform message paylaod

    const transformedData = transformFreeformMessagePayload(payload)
    console.log(start - Date.now(), 'ms')


    return transformedData;

  }
}

//Sub function to transform the CleverTap payload of Template Message to BMP
function transformTemplateMessagePayload(payload) {


  //Transforming the data using payload directly without using mapping model because of the array type data
  let mappingModel = {}
  let bmpUrl = ""

  if (payload.components.length == 1) {
    const bodyComponent = payload.components.find(
      (component) => component.type === 'body'
    )

    mappingModel = {
      platform: 'WA',
      from: payload['wabaNumber'],
      to: payload['to'],
      type: 'template',
      templateName: payload['template']['namespace'],
      templateLang: payload['template']['languageCode'],
      templateData: bodyComponent.body.parameters.map(
        (parameter) => parameter.text
      ),
      channel: 'CAMPAIGN',
      tag1: payload.msgId
    }

    bmpUrl = BMP_API_Map.get('Templatized text message') 
  } else {
    const hasHeader = payload.components.find(
      (component) => component.type === 'header'
    )
    if (hasHeader) {
      const bodyComponent = payload.components.find(
        (component) => component.type === 'body'
      )

      console.log("HasHeader", hasHeader)

      mappingModel = {
        platform: 'WA',
        from: payload['wabaNumber'],
        to: payload['to'],
        type: 'template',
        templateName: payload['template']['namespace'],
        templateLang: payload['template']['languageCode'],
        templateData: bodyComponent.body.parameters.map(
          (parameter) => parameter.text
        ),
        headerType: hasHeader.header.type,
        header: hasHeader.header.file.mediaURL
      }

    bmpUrl = BMP_API_Map.get('Templatized text message') 

    }
  }







  // console.log('\n\nTransformed Data\n\n', mappingModel)

  return { "transformedData": mappingModel, "url": bmpUrl, "msgId" : payload.msgId};

}

//Sub function to transform the CleverTap payload of Freeform Message to BMP

function transformFreeformMessagePayload(payload) {

  //Creating mapping model based on the type of data
  let mappingModel = {}
  if (payload.type == 'image') {
    mappingModel = {
      file: 'image.mediaURL',
      from: 'wabaNumber',
      to: 'to',
      mediaType: 'type',
      text: 'image.caption'
    }
  } else if (payload.type == 'text') {
    mappingModel = {
      platform: 'WA',
      from: 'wabaNumber',
      to: 'to',
      type: 'type',
      text: 'text.body'
    }
  }

  //transforming the payload to BMP w.r.t the content type which is expected by BMP

  let transformedJSONData = {};
  let transformedFormData = new FormData();


  if (payload.type == 'image') {
    Object.keys(mappingModel).map((eachKey, keyIndex) => {
      if (mappingModel[eachKey].includes('.')) {
        const propertyName = mappingModel[eachKey]
        const keys = propertyName.split('.')

        transformedFormData.append(
          eachKey,
          keys.reduce((value, key) => value && value[key], payload)
        )
      } else {
        transformedFormData.append(eachKey, payload[mappingModel[eachKey]])
      }
    })


    return { "transformedData": transformedFormData, 'url': BMP_API_Map.get('Freeform message with image') , "msgId" : payload.msgId};

  } else if (payload.type == 'text') {
    Object.keys(mappingModel).map((eachKey, keyIndex) => {

      if (mappingModel[eachKey].includes('.')) {
        const propertyName = mappingModel[eachKey]
        const keys = propertyName.split('.')
        transformedJSONData[eachKey] = keys.reduce(
          (value, key) => value && value[key],
          payload
        )
      } else {
        transformedJSONData[eachKey] = (eachKey == "platform" ? "WA" : payload[mappingModel[eachKey]]);
      }
    })

    return { "transformedData": transformedJSONData, 'url': BMP_API_Map.get('Freeform message with only text') , "msgId" : payload.msgId};
  }
}


module.exports = { transform }