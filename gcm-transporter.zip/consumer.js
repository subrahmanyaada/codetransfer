const amqp = require("amqplib");
const config = require("./config");
const Dispatch = require("./dispatch");
const dispatch = new Dispatch()
const { transform } = require('./clevertaptransformation')

const { validateCleverTapPayload } = require("./validation")
const {storeTransformedMessage} = require("./in-mem-utils")


class Consume {
    channel;

    async createChannel() {
        const connection = await amqp.connect(config.rabbitMQ.url);
        this.channel = await connection.createChannel();
    }

    async consumeMessages() {
        if (!this.channel) {
            await this.createChannel();
        }

        const exchangeName = config.consumeQ.exchangeName;
        const qName = config.consumeQ.qName;
        const routeKeyQ1 = config.consumeQ.routingKey;
        await this.channel.assertExchange(exchangeName, "direct");

        const q = await this.channel.assertQueue(qName);

        await this.channel.bindQueue(q.queue, exchangeName, routeKeyQ1);


        this.channel.consume(q.queue, (msg) => {

            
            const payload = JSON.parse(msg.content);


            setTimeout(this.onTimeOut, 5,payload );
            this.channel.ack(msg); // may be later move this to no ack
        });
    }

    async onTimeOut(data) {

        

        const payload = JSON.parse(data.message)

        //TODO store tenant id into redis DB
        // TODO validate

        const isValidate = validateCleverTapPayload(payload)
        if (isValidate) {
            // TODO transform
            const result = transform(payload)

            //Storing transformed data
            storeTransformedMessage(result)
            // TODO store
            result['dateTime'] = data.dateTime

            console.log("\n\nTimetaken to transformation from the collection",result, data.dateTime - Date.now())
            await dispatch.publishMessage(result)
        }
        else {
            console.log("Required fields are not there")
        }

       

    }
}



module.exports = Consume;