const amqp = require("amqplib");
const config = require("./config");

class Dispatch {
  channel;

  async createChannel() {
    const connection = await amqp.connect(config.rabbitMQ.url);
    this.channel = await connection.createChannel();
  }

  async publishMessage(payload) {
    if (!this.channel) {
      await this.createChannel();
    }

    const exchangeName = config.dispatchQ.exchangeName;
    const routingKey = config.dispatchQ.routingKey;

    await this.channel.assertExchange(exchangeName, "direct");

   
    const logDetails = {
      logType: routingKey,
      message: payload.transformedData,
      url: payload.url,
      dateTime: payload.dateTime,
    };

    await this.channel.publish(
      exchangeName,
      routingKey,
      Buffer.from(JSON.stringify(logDetails))
    );

    console.log(
      // `Transport Dispatch ${routingKey} log is sent to exchange ${exchangeName}`
      `Transport Dispatch `
    );
  }
}

module.exports = Dispatch;
