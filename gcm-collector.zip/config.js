module.exports = {
  rabbitMQ: {
    url: "amqp://127.0.0.1",
    exchangeName: "logExchange",
  },
};
