const express = require("express");
const bodyParser = require("body-parser");
const app = express();
const Producer = require("./producer");
const producer = new Producer();
const {storeCleverTapMessage} = require("./in-mem-utils")

const PORT = 3000
app.use(bodyParser.json("application/json"));

app.get("/test", async (req, res) => {

    const msg = JSON.stringify({
        "payloadVersion": 0.1,
        "to": "628116823073",
        "msg_id": "25596363|1639561857|20220227|25596363",
        "wabaNumber": "6282124537231",
        "type": "text",
        "isTemplate": false,
        "text": {
            "body": "Freeform message with only text"
        }
    })


    await producer.publishMessage("Info", msg);
    res.send();
});


//TBD - apikey & payload
app.post("/v1/messages/ctap/sendmessage", async (req, res) => {

    const requestData = req.body;

    storeCleverTapMessage(requestData)    
    requestData['tenant_id'] = "ctap"

    console.log(requestData)

    await producer.publishMessage("Info", JSON.stringify(requestData));
    res.send();
});

app.post("/v1/messages/ucw/sendmessage", async (req, res) => {

    const requestData = req.body;
    requestData['tenant_id'] = "ucw"

    await producer.publishMessage("Info", JSON.stringify(requestData));
    res.send();
});

app.listen(PORT, () => {
    console.log("GCM collector listening at " + PORT)
})