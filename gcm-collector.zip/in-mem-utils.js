const redis = require('redis');

// Create a Redis client
const client = redis.createClient({
  host: '127.0.0.1', 
  port: 6379,
});

async function storeToRedis(key,value){
  client.set(key, value, (err, reply) => {
    if (err) {
    
      console.error(' Error While Storing Schema To Redis', err);
  
    } else {
      console.log('Schema Stored Successfully:', reply);
    }
  });
  
  }
  


async function storeCleverTapMessage(clevertapPayload){

  const msgId= clevertapPayload["msgId"];
  const payloadString=JSON.stringify(clevertapPayload)

  console.log("In-memory-utils", payloadString)

  storeToRedis(msgId,payloadString)
}


// storeCleverTapMessage(clevertapPayload)

module.exports = {storeCleverTapMessage}