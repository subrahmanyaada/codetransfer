const redisServer = {
  host: '127.0.0.1',
  // host: "redis",
  port: 6379,
};

module.exports = { redisServer };
