const axios = require('axios');

const redis = require('redis');

// Create a Redis client
const client = redis.createClient({
  host: '127.0.0.1', 
  port: 6379,
});



async function storeToRedis(key,value){
client.set(key, value, (err, reply) => {
  if (err) {
  
    console.error(' Error While Storing Schema To Redis', err);

  } else {
    console.log('Schema Stored Successfully:', reply);
  }
});

}

async function storeCleverTapMessage(clevertapPayload){

  const msgId= clevertapPayload["msgId"];
  const payloadString=JSON.stringify(clevertapPayload)

  storeToRedis(msgId,payloadString)
}



// bmp-all-templates-timestamp {entire response} 



async function getTemplateList(){
    const url = 'https://cw78bzhole.execute-api.ap-southeast-3.amazonaws.com/staging/usermgt/template';
    const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjbGllbnRJZCI6Ijc0ZWJlYWUwLTk2MmYtNDhjZS04N2RjLWIyNGFjOThlZmZlZCIsImNvdW50cnlDb2RlIjoiSUQiLCJlbWFpbCI6ImFkYS1hZG1pbi1pbmRvMUBhZGEtYXNpYS5jb20iLCJleHAiOjIyOTkyNjM3OTksImlhdCI6MTY2ODExMTc5OSwibmFtZSI6IkFkbWluIFRlc3RpbmcgMSIsInJvbGVDb2RlIjoiT1dORVIiLCJyb2xlSWQiOiJPV05FUiIsInNpZCI6ImFwaWtleSIsInVpZCI6IjNmYTkyOWQ2LWI1NWMtNGUzZi1iOWU0LTQxYmJjZmE2ZmJkMSJ9.CiMnaknyWSvPQN5icLV98sCOsbGXcNseBkBSY3PdV2M';

    const headers = {
      Authorization: `Bearer ${token}`
    };

    const response = await axios.get(url, { headers });

    const timestamp=new Date().toISOString();

    const keyName='bmp-all-templates-'+timestamp
    const  teplatedata= JSON.stringify(response.data);

    storeToRedis(keyName,teplatedata)


}





async function  splitTemplates(){

const templates= await  getTemplateList();

  const templateObject = {};
  for (const item of templates) {
    const templateName = item.name;
    templateObject[templateName] = item;
  }
  return templateObject


}








async function storeTransformedMessage(transformedMessage){

  const msgId= 't'+ transformedMessage["msgId"];

  const payloadString=JSON.stringify(transformedMessage);

  storeToRedis(msgId,payloadString)


}



const transformedMessage={
  "payloadVersion": "payloadVersion",
  "to": "to",
  "wabaNumber": "businessWabaNumber",
  "isTemplate": true,
  "msgId": "123",
  "template": {
      "namespace": "testing_param1",
      "languageCode": "BSPsr-language-and-locale-code"
  }
}

const clevertapPayload={
    "payloadVersion": "payloadVersion",
    "to": "to",
    "wabaNumber": "businessWabaNumber",
    "isTemplate": true,
    "msgId": "123",
    "template": {
        "namespace": "testing_param1",
        "languageCode": "BSPsr-language-and-locale-code"
    },
    "components": [     
        {
            "type": "body",
            "body": {
                "text": "Body",
                "parameters": [ {
                        "type": "text",
                        "text": "PlaceholderText1"
                    }
                ]
            }
        }
        
    ] 
}


storeCleverTapMessage(clevertapPayload)
getTemplateList()
storeTransformedMessage(transformedMessage)