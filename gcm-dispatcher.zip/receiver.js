const Consume = require("./consumer");
const consume = new Consume();

async function listen() {
  await consume.consumeMessages()
}

listen()
