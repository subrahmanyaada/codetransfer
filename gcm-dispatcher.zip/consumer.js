const amqp = require("amqplib");
const config = require("./config");
const axios = require('axios')

class Consume {
  channel

  async createChannel() {
    const connection = await amqp.connect(config.rabbitMQ.url);
    this.channel = await connection.createChannel();
  }

  async consumeMessages() {
    if (!this.channel) {
      await this.createChannel();
    }

    const exchangeName = config.consumeQ.exchangeName;
    const qName = config.consumeQ.qName;
    const routeKeyQ1 = config.consumeQ.routingKey;
    await this.channel.assertExchange(exchangeName, "direct");

    const q = await this.channel.assertQueue(qName);

    await this.channel.bindQueue(q.queue, exchangeName, routeKeyQ1);

    this.channel.consume(q.queue, (msg) => {

      console.log("\n\nmsg\n\n", msg)
      if (msg.content) {
        const payload = JSON.parse(msg.content.toString())

        console.log(payload);

        setTimeout(this.onTimeOut, 5, payload);
      }
      this.channel.ack(msg); // may be later move this to no ack
    });
  }

  async onTimeOut(transform) {

    // TODO push to BMP

    console.log("Before Calling API", transform.dateTime - Date.now())
    const data = JSON.stringify(transform.message)
    

    let config = {
      method: 'post',
      maxBodyLength: Infinity,
      url: "https://cw78bzhole.execute-api.ap-southeast-3.amazonaws.com/staging/usermgt/" + transform.url,
      headers:  {
        'Content-Type': transform.url == "message" ? 'application/json': 'multipart/form-data; boundary=${data._boundary}',
        'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjbGllbnRJZCI6Ijc0ZWJlYWUwLTk2MmYtNDhjZS04N2RjLWIyNGFjOThlZmZlZCIsImNvdW50cnlDb2RlIjoiSUQiLCJlbWFpbCI6ImFkYS1hZG1pbi1pbmRvMUBhZGEtYXNpYS5jb20iLCJleHAiOjIyOTkyNjM3OTksImlhdCI6MTY2ODExMTc5OSwibmFtZSI6IkFkbWluIFRlc3RpbmcgMSIsInJvbGVDb2RlIjoiT1dORVIiLCJyb2xlSWQiOiJPV05FUiIsInNpZCI6ImFwaWtleSIsInVpZCI6IjNmYTkyOWQ2LWI1NWMtNGUzZi1iOWU0LTQxYmJjZmE2ZmJkMSJ9.CiMnaknyWSvPQN5icLV98sCOsbGXcNseBkBSY3PdV2M'
      } ,
      data: data
    };
    axios.request(config)
      .then((response) => {
        console.log("\n\nResponse\n\n", JSON.stringify(response.data), "\n\n", transform.dateTime - Date.now());
      })
      .catch((error) => {
        console.log(error);
      });


    // const FormData = require('form-data');
    // let data = new FormData();
    // data.append('file', fs.createReadStream('/home/kavya/Pictures/Screenshot from 2023-05-31 23-20-04.png'));
    // data.append('from', '62895384202737');
    // data.append('to', '628116823073');
    // data.append('mediaType', 'image');
    // data.append('text', 'test2');

    // let config = {
    //   method: 'post',
    //   maxBodyLength: Infinity,
    //   url: 'https://cw78bzhole.execute-api.ap-southeast-3.amazonaws.com/staging/usermgt/message/media',
    //   headers: { 
    //     'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjbGllbnRJZCI6Ijc0ZWJlYWUwLTk2MmYtNDhjZS04N2RjLWIyNGFjOThlZmZlZCIsImNvdW50cnlDb2RlIjoiSUQiLCJlbWFpbCI6ImFkYS1hZG1pbi1pbmRvMUBhZGEtYXNpYS5jb20iLCJleHAiOjIyOTkyNjM3OTksImlhdCI6MTY2ODExMTc5OSwibmFtZSI6IkFkbWluIFRlc3RpbmcgMSIsInJvbGVDb2RlIjoiT1dORVIiLCJyb2xlSWQiOiJPV05FUiIsInNpZCI6ImFwaWtleSIsInVpZCI6IjNmYTkyOWQ2LWI1NWMtNGUzZi1iOWU0LTQxYmJjZmE2ZmJkMSJ9.CiMnaknyWSvPQN5icLV98sCOsbGXcNseBkBSY3PdV2M', 
    //     ...data.getHeaders()
    //   },
    //   data : data
    // };

    // console.log("FormData", data)

    // axios.request(config)
    // .then((response) => {
    //   console.log(JSON.stringify(response.data));
    // })
    // .catch((error) => {
    //   console.log(error);
    // });


  }

}

module.exports = Consume